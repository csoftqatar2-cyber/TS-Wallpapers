# Handoff: THABTHABA STORE (ثبثبة ستور) — Car Head‑Unit App Store · "Warm Aurora" direction

## Overview
THABTHABA STORE is an Android app‑store application for **car infotainment head units** (Chinese / EV vehicles). The user picks their car model, then browses and installs compatible APKs directly onto the car screen over **wireless ADB** (no manual whitelist step). The UI is **Arabic, right‑to‑left (RTL)**, dark glassmorphism theme with a warm gold/amber accent.

This bundle documents the **"Warm Aurora" (1b)** visual direction across all 7 core screens.

## About the design files
The files in this bundle are **design references created in HTML** — prototypes showing the intended look, layout, and behavior. They are **not production code to copy directly**. The task is to **recreate these designs in the target codebase's existing environment** (Android native / Kotlin+Jetpack Compose is the natural fit for a head‑unit APK; React Native / Flutter also viable) using that environment's established patterns, then wire up the real ADB install logic. If no environment exists yet, pick the most appropriate framework for an on‑device head‑unit app and implement there.

The HTML uses a small streaming component runtime (`support.js`) and inline styles — treat it purely as a spec, not as a code source.

## Fidelity
**High‑fidelity (hifi).** Final colors, typography, spacing, radii, shadows, and the install animation are all intended as‑shown. Recreate pixel‑faithfully, then substitute real app icons/screenshots (the mock uses monogram placeholder tiles and gradient placeholder rectangles).

## Target canvas
- **Screen:** landscape **1280 × 720** (common Chinese head‑unit resolution). Design should scale up to 1920×1080 gracefully.
- **Direction:** **RTL** everywhere. Navigation mirrored, text right‑aligned, directional icons flipped. Numerals/model names/versions stay LTR (wrap those runs in `dir="ltr"`).
- **Base theme:** dark only.

---

## Design tokens

### Colors
| Token | Value | Use |
|---|---|---|
| `--bg` | `#14100b` | App background (warm near‑black) |
| `--bg2` | `#1c160e` | Slightly raised surfaces |
| `--glass` | `rgba(46,36,23,.5)` + `backdrop-filter: blur(24–28px)` | Card / panel glass |
| `--glass2` | `rgba(54,42,27,.74)` + `blur(28px)` | Floating bottom nav |
| `--bd` | `rgba(255,214,160,.14)` | Borders / hairlines |
| `--tx` | `#f5eee4` | Primary text |
| `--mut` | `#b0a48f` | Muted / secondary text |
| `--acc` | `#ff9a3d` | Accent orange |
| `--gold` | `#ffd27a` | Accent gold |
| `--glow` | `rgba(255,160,60,.4)` | Glow shadow color |
| Button text on accent | `#1a1204` | Dark brown for legibility on gold |
| Success | `#34d399` | "متصل"/"متوافق" states |

**Primary gradient (buttons, active nav, active states):** `linear-gradient(135deg, var(--acc), var(--gold))`.

**Category colors:** media/وسائط `#ff5b7f` · navigation/ملاحة `#34d399` · system/نظام `#ff9a3d` · tools/أدوات `#9b8cff` · games/ألعاب `#ffc24b` · communication/تواصل `#4ad6c4` · browsers/متصفحات `#5aa9ff`.

### Typography
- **Cairo** — all Arabic UI text. Weights 400 / 500 / 600 / 700 / 800.
- **Rajdhani** — Latin words and all numerals (model names, versions, file sizes, clock, percentages). Weights 500 / 600 / 700. Slightly condensed, techy.
- Scale: screen titles `800, 24–34px`; card titles `700, 16–17px`; body/muted `400–500, 12–14px`; nav labels `500/700, 15px`; stat numbers `700, 20px` (Rajdhani).

### Radii
Frame `26px` · cards/panels `20–24px` · buttons `14–18px` · chips/pills/list‑icon tiles `10–18px` · toggles & count badges `99px`.

### Shadows
Cards `0 8px 24px rgba(0,0,0,.2)` · floating nav `0 24px 60px rgba(0,0,0,.5)` · accent buttons `0 6–12px var(--glow)` · app‑icon tiles `0 8px 20px rgba(0,0,0,.35)`.

### Motion (keyframes)
- `spin` — 360° rotate, used for the install halo (`1.1s linear infinite`).
- `pulseGlow` — opacity .55↔1, splash halo / rings (`3–4s ease-in-out`).
- `floaty` — translateY 0↔‑12px, splash logo (`6s ease-in-out`).
- `barFill` — width 6%↔74%, splash loading bar (`2.4s`).
- `blink` — opacity 1↔.2, status dots (`1.3–1.4s`, staggered 0/.2/.4s for the 3‑dot loader).
- `auroraDrift` — translate+scale, ambient background blobs (`14–16s`).

---

## Screens / views

All screens share: dark frame (1280×720, radius 26, 1px `--bd` border), ambient blurred radial "aurora" blob(s) in warm tones, and — on the four main tabs — a **floating segmented bottom nav** centered at `bottom:22px`.

### Bottom nav (shared)
Segmented pill: `--glass2`, `blur(28px)`, `1px --bd`, radius `24px`, padding `7px`. Four items, each `padding:13px 24–26px`, radius `18px`, icon `19px` + Cairo `15px` label. **Active** item = primary gradient fill, text `#1a1204`, `box-shadow:0 6px 18px var(--glow)`. Inactive = `--mut`, no fill.
Order (RTL, right→left): **التطبيقات (Apps) · التحديثات (Updates) · الخلفيات (Wallpapers) · الإعدادات (Settings)**. Icons: apps = 2×2 rounded squares; updates = down‑arrow into a tray line; wallpapers = image/mountain glyph; settings = two sliders.

### 01 · Splash — شاشة البداية
Full‑bleed radial warm gradient background. Centered: logo (`assets/logo-light.png`, ~400px wide) with `floaty` + drop‑shadow, wrapped in two concentric faint gold rings (300px & 380px). Tagline **"متجرك لتطبيقات شاشة السيّارة"** (Cairo 600 17px, `--mut`). Below: three gold dots (11px) blinking staggered. Footer **"الاتصال بالسيّارة عبر ADB اللاسلكي"** (Cairo 500 13px). Auto‑advances to Car Select (or Home if a car is already chosen) once connected.

### 02 · Car Select — اختيار السيّارة
Centered header: title **"اختر سيّارتك"** (Cairo 800 34px) + subtitle **"حدّد الموديل لعرض التطبيقات المتوافقة مع شاشتك"**. Below: **3‑column grid** of car cards (`grid-template-columns:repeat(3,1fr)`, gap 20px). Card = glass panel radius 24px, centered column: a `88×60` rounded gold‑tinted tile holding a line‑art car icon (gold), then model name (Rajdhani 700 18px, LTR) + Arabic transliteration (Cairo 400 13px `--mut`). **Selected** card: gold border + `0 0 34px var(--glow)` glow + a **"محدّدة"** pill (gradient) top‑corner. Models: DENZA, DENZA 2, BYD SHARK, LYNK & CO, TANK 500, HAVAL H9, DONG FENG, ICAUR, JETOUR T2. Tapping selects → proceeds to Home.

### 03 · Home / Apps — الرئيسية · التطبيقات
Top bar (h 70): brand cluster on the **right** (logo mark 40px + "ثبثبة ستور" Cairo 800 18px); on the left a search pill ("ابحث…", 300px), the selected‑car pill (gold car glyph + "DENZA"), and the clock (Rajdhani 600 17px).
Body = 2‑col grid `186px 1fr` (gap 22px). **Right = category rail** (glass panel): vertical list, each row = color dot + Arabic label; active row ("الكل") = gradient fill. **Left = app list**: 2‑column grid of horizontal app cards. Card = glass, radius 20px: `60px` gradient icon tile (monogram placeholder) + name (Cairo 700 16px) + a category chip (tinted by category color) + size (Rajdhani) + an **install button** (gradient, "تثبيت"/"فتح"/"تحديث"). One card demonstrates the **installing state** (see Interactions). Floating nav, Apps active.

### 04 · App Details — تفاصيل التطبيق
Full‑width **hero banner** (h 230) in the app's brand gradient with diagonal texture + bottom fade; a back button (chevron, RTL‑pointing) top‑right. The app icon (`120px`, radius 30, 3px `--bg` ring) overlaps the hero bottom edge (`margin-top:-64px`), beside the name (Cairo 800 32px) + "YouTube · Google LLC · ⭐ 4.7" (Rajdhani), with a large **"تثبيت · 82 MB"** button pushed to the far edge. Below: a 4‑up **stat row** (glass tiles): الحجم / الإصدار / التحميلات / a green "متوافق ✓ مع DENZA" compatibility tile. Then a 3‑up **screenshots** row (16:9 placeholder rectangles — replace with real screenshots; support a carousel).

### 05 · Updates — التحديثات
Top bar: title **"التحديثات المتاحة"** + a gradient count badge, and a **"تحديث الكل"** button (gradient). List of update rows (glass, radius 22): 62px icon tile + name + version transition `fromVersion › toVersion · size` (Rajdhani) + a **"تحديث"** button. The in‑progress row swaps the button for a **progress bar** (200×8, gold gradient) + percentage (Rajdhani gold). Floating nav, Updates active.

### 06 · Wallpapers — الخلفيات
Top bar: title **"الخلفيات"** + hint "اختر خلفية لمعاينتها قبل التطبيق". Body = **4‑column × 2‑row grid** of wallpaper tiles (radius 20, bottom‑fade, name label). **Selected** tile: gold border + inner glow + a floating **"تطبيق"** button. (Real behavior: tapping a tile opens a fullscreen preview with Apply/Cancel before setting the head‑unit wallpaper.) Floating nav, Wallpapers active.

### 07 · Settings — الإعدادات
Centered single column (~780px). Title "الإعدادات". Grouped glass cards:
- **Connection:** ADB اللاسلكي (toggle ON) · عنوان الجهاز `192.168.1.42:5555` + green "متصل" badge · البحث التلقائي عن السيّارة (toggle ON).
- **General:** اللغة (العربية, chevron) · التحديث التلقائي للتطبيقات (toggle OFF) · التخزين المستخدم `4.8 / 32 GB`.
- **About:** logo mark + "ثبثبة ستور" + `v2.5.0 · build 2507`.
Toggle = 56×32 pill; ON = gradient + glow + white knob left; OFF = grey track, grey knob right. Floating nav, Settings active.

---

## Interactions & behavior
- **Tab navigation:** the four bottom‑nav items switch between Apps / Updates / Wallpapers / Settings. Animate the active segment (slide/crossfade). Splash → Car Select → Home is a linear onboarding flow; Home ⇄ App Details via card tap and back button.
- **Install over wireless ADB (key flow):** tapping **تثبيت** transitions the button → an **install progress control**: a `52px` ring with an SVG stroke arc (`stroke: var(--gold)`, `stroke-width:5`, rotated ‑90° so it fills from top) driven by real progress, an outer **spinning halo** (`border-top-color: var(--acc); animation: spin 1.1s linear infinite`), and the live **percentage** centered (Rajdhani gold). On completion the control becomes a **"فتح"** button. Errors (ADB disconnected, incompatible, insufficient storage) should surface inline on the card. Consider a full‑screen install overlay for large APKs.
- **Updates:** same progress vocabulary, shown as a horizontal bar + %; "تحديث الكل" queues all.
- **Wallpapers:** select → preview → apply.
- **Toggles:** immediate state flip with the gradient/grey transition.
- **Hover/press (touch head‑unit):** cards lift shadow slightly; buttons darken/scale 0.98 on press. Keep hit targets ≥ 44px.

## State management
- `selectedCarModel` (drives compatibility filtering + the Home car pill).
- `currentTab` ∈ {apps, updates, wallpapers, settings}.
- Per‑app `installState` = `idle | installing(progress 0–100) | installed | failed(reason)`.
- Per‑update `updateState` = `available | updating(progress) | done`.
- `selectedWallpaperId` + applied wallpaper.
- Settings flags: `adbWireless`, `autoDiscoverCar`, `autoUpdate`, `language`, plus device `adbAddress`, `connectionStatus`, `storageUsed/Total`.
- ADB session state: connection status + device address (surfaced in Settings).

## Suggested data model (for real API / ADB layer)
```jsonc
Car      { id, name /*LTR*/, nameAr, iconRef }
App      { id, nameAr, latinName, category, sizeBytes, version,
           iconColor1, iconColor2 /*until real icons*/, iconUrl,
           rating, downloads, apkUrl, compatibleModels[], screenshots[] }
Update   { appId, fromVersion, toVersion, sizeBytes }
Wallpaper{ id, nameAr, imageUrl /* mock uses CSS gradients as placeholders */ }
```
Categories enum: `media, navigation, system, tools, games, communication, browsers`.

## Assets
- **`assets/logo-light.png`** — full logo (calligraphy mark + wordmark) recolored to warm‑white + gold so it reads on the dark theme. Use on Splash / About.
- **`assets/logo-mark-light.png`** — just the calligraphy monogram, warm‑white; use in top bars.
- **`logo-source/`** — the **original brand logo** (`Photoroom_...png`, transparent; `pasted-...png`) in its real colors (gold `#a8894f`‑ish + charcoal). Use these as the source of truth; generate any additional color variants from them. On light surfaces use the original; on dark use the light variants provided.
- **Icons:** car glyph and the four nav icons are simple inline SVGs (documented above) — reproduce as vector assets. **App icons** in the mock are monogram gradient tiles — **replace with each APK's real launcher icon.** Screenshots are placeholder rectangles.
- **Fonts:** Cairo + Rajdhani (Google Fonts). Bundle locally for an offline head‑unit.

## Files
- `THABTHABA_STORE_1b.dc.html` — the hi‑fi prototype (all 7 screens, "Warm Aurora"). Open in a browser to inspect. It's a spec/reference, not shippable code.
- `assets/`, `logo-source/` — as above.
